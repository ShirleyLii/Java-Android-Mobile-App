package cis436project4;

import android.content.res.Resources;
/**
 * Created by JRavelo on 8/12/2017.
 */

public class Food {

    int index;
    String name, category, link, image;
    boolean favorite;
}
