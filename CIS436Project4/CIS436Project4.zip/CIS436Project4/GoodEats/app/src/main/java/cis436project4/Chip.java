package cis436project4;

/**
 * Created by JRavelo on 8/12/2017.
 */

//Simple class used to hold a master list of all DB filters for the ChipRecycleView Adapter
public class Chip {
    public static String[] category = {
        "American", "Latin", "Japanese", "French", "Indian", "Italian", "Chinese"
    };
}
